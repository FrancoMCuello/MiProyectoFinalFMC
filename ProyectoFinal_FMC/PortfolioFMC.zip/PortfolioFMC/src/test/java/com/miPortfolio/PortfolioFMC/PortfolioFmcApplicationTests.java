package com.miPortfolio.PortfolioFMC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioFmcApplicationTests {

	@Test
	void contextLoads() {
	}

}
