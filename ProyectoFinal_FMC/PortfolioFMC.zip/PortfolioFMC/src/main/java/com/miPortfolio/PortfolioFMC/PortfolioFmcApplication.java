package com.miPortfolio.PortfolioFMC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioFmcApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioFmcApplication.class, args);
	}

}
